const express = require('express');
const router = express.Router();
const intentDetector = require('./ai/intentDetector');

// Chat endpoint
router.post('/chat', async (req, res) => {
    try {
        const { message } = req.body;
        
        if (!message) {
            return res.status(400).json({ error: 'Message is required' });
        }

        // Get response from intent detector
        const response = await intentDetector.processMessage(message);
        
        res.json({ response });
    } catch (error) {
        console.error('Error processing message:', error);
        res.status(500).json({ error: 'An error occurred while processing your message' });
    }
});

module.exports = router;
