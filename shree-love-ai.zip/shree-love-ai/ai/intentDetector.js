const science = require('../knowledge/science');
const geography = require('../knowledge/geography');
const economics = require('../knowledge/economics');
const gk = require('../knowledge/gk');
const indianGK = require('../knowledge/indianGK');
const assamGK = require('../knowledge/assamGK');
const assamHistory = require('../knowledge/assamHistory');
const garoCulture = require('../knowledge/garoCulture');
const religion = require('../knowledge/religion');
const fullForms = require('../knowledge/fullForms');
const mathEngine = require('../knowledge/mathEngine');
const greetings = require('../knowledge/greetings');
const romantic = require('../knowledge/romantic');
const quotes = require('../knowledge/quotes');
const motivation = require('../knowledge/motivation');
const personal = require('../knowledge/personal');

class IntentDetector {
    constructor() {
        this.intents = {
            greeting: {
                keywords: ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening', 'greetings', 'sup', 'howdy'],
                handler: greetings
            },
            math: {
                pattern: /[\d+\-*/().%=]+/,
                handler: mathEngine
            },
            economics: {
                keywords: ['gdp', 'inflation', 'economy', 'market', 'demand', 'supply', 'tax', 'fiscal', 'monetary', 'recession', 'trade', 'export', 'import'],
                handler: economics
            },
            science: {
                keywords: ['atom', 'gravity', 'energy', 'photosynthesis', 'physics', 'chemistry', 'biology', 'force', 'mass', 'molecule', 'cell', 'electron', 'proton', 'neutron', 'chemical', 'reaction'],
                handler: science
            },
            geography: {
                keywords: ['capital', 'country', 'river', 'mountain', 'continent', 'ocean', 'geography', 'city', 'state', 'nation', 'border'],
                handler: geography
            },
            gk: {
                keywords: ['president', 'prime minister', 'who invented', 'when was', 'general knowledge', 'world', 'international'],
                handler: gk
            },
            indianGK: {
                keywords: ['india', 'indian', 'delhi', 'mumbai', 'kolkata', 'chennai', 'bengaluru', 'modi', 'gandhi', 'nehru', 'parliament'],
                handler: indianGK
            },
            assamGK: {
                keywords: ['assam', 'guwahati', 'dispur', 'brahmaputra', 'kaziranga', 'bihu', 'assamese'],
                handler: assamGK
            },
            assamHistory: {
                keywords: ['ahom', 'assam history', 'lachit', 'sukapha'],
                handler: assamHistory
            },
            garoCulture: {
                keywords: ['garo', 'meghalaya', 'wangala', 'garo culture', 'garo hills'],
                handler: garoCulture
            },
            religion: {
                keywords: ['god', 'jesus', 'christ', 'bible', 'hindu', 'krishna', 'rama', 'shiva', 'religion', 'prayer', 'temple', 'church'],
                handler: religion
            },
            fullForms: {
                keywords: ['full form', 'nasa', 'who', 'isro', 'un', 'fbi', 'cia', 'stands for', 'abbreviation'],
                handler: fullForms
            },
            romantic: {
                keywords: ['love', 'miss you', 'romantic', 'darling', 'sweetheart', 'honey', 'baby', 'crush', 'date', 'kiss', 'hug'],
                handler: romantic
            },
            quotes: {
                keywords: ['quote', 'saying', 'wisdom', 'proverb'],
                handler: quotes
            },
            motivation: {
                keywords: ['motivate', 'inspire', 'inspiration', 'motivation', 'encourage', 'success', 'dream', 'goal'],
                handler: motivation
            },
            personal: {
                keywords: ['your name', 'who are you', 'who created you', 'who made you', 'your age', 'how old are you', 'your purpose', 'what can you do'],
                handler: personal
            }
        };
    }

    normalizeText(text) {
        return text.toLowerCase().trim();
    }

    detectIntent(message) {
        const normalized = this.normalizeText(message);

        // Check for math patterns first
        if (this.intents.math.pattern.test(normalized) && /\d/.test(normalized)) {
            return 'math';
        }

        // Check for keyword matches
        for (const [intent, config] of Object.entries(this.intents)) {
            if (config.keywords) {
                for (const keyword of config.keywords) {
                    if (normalized.includes(keyword)) {
                        return intent;
                    }
                }
            }
        }

        return 'unknown';
    }

    async processMessage(message) {
        const intent = this.detectIntent(message);

        if (intent === 'unknown') {
            return "I don't have information about that yet, but I'm always learning.";
        }

        const handler = this.intents[intent].handler;
        return handler.respond(message);
    }
}

module.exports = new IntentDetector();
