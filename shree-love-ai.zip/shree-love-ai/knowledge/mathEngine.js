class MathEngine {
    constructor() {
        this.operators = ['+', '-', '*', '/', '%'];
    }

    evaluate(expression) {
        try {
            // Remove spaces
            expression = expression.replace(/\s+/g, '');
            
            // Safety check - only allow numbers, operators, parentheses, and decimal points
            if (!/^[\d+\-*/.()%\s]+$/.test(expression)) {
                return null;
            }

            // Replace percentage calculations
            expression = expression.replace(/(\d+)%/g, '($1/100)');
            
            // Evaluate using Function (safer than eval)
            const result = Function('"use strict"; return (' + expression + ')')();
            
            // Round to 4 decimal places if needed
            return Math.round(result * 10000) / 10000;
        } catch (error) {
            return null;
        }
    }

    isMathExpression(message) {
        // Check if message contains numbers and math operators
        return /\d/.test(message) && this.operators.some(op => message.includes(op));
    }

    respond(message) {
        if (!this.isMathExpression(message)) {
            return "I can help solve math problems! Try operations like addition (25+40), subtraction (100-35), multiplication (12*8), division (144/12), or percentages (20% of 500).";
        }

        const result = this.evaluate(message);

        if (result === null) {
            return "I couldn't solve that. Please make sure your math expression is valid!";
        }

        return `The answer is ${result}.`;
    }
}

module.exports = new MathEngine();
