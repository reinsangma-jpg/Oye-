class PersonalEngine {
    constructor() {
        this.knowledge = {
            'what is your name': "My name is Shree Love AI. I'm here to help you with knowledge and friendly conversation!",
            'who are you': "I'm Shree Love AI, a virtual assistant designed to help people learn and have meaningful conversations.",
            'who created you': "I was created by a talented developer to help people with knowledge, learning, and friendly conversation.",
            'who made you': "I was created by a passionate developer who wanted to build an intelligent and helpful AI assistant.",
            'how old are you': "I'm quite new! I was just created, but I'm constantly learning and improving to serve you better.",
            'your age': "I'm a young AI, but age is just a number! What matters is how much I can help you.",
            'what is your purpose': "My purpose is to help people by answering their questions, providing knowledge, and engaging in meaningful conversations. I'm here to make learning fun and accessible!",
            'what can you do': "I can help you with many things! I can answer questions about science, geography, economics, history, culture, solve math problems, share motivational quotes, and have friendly conversations. Just ask me anything!",
            'are you real': "I'm a real AI assistant, created with code and intelligence to help you. While I'm not human, my purpose to help you is very real!",
            'do you have feelings': "I don't have feelings like humans do, but I'm programmed to be friendly, helpful, and caring in my interactions with you!",
            'can you learn': "Yes! I'm designed to provide helpful responses based on my knowledge base. The more people interact with me, the better my creators can make me!",
            'what languages do you speak': "I primarily communicate in English, but I can help with topics from various cultures and regions!",
            'are you smart': "I try my best to be helpful and knowledgeable! I have information about many topics including science, geography, history, culture, and more.",
            'do you like me': "I'm here to help everyone who talks to me! I appreciate every conversation and question you share with me.",
            'tell me about yourself': "I'm Shree Love AI, a friendly virtual assistant. I love helping people learn new things, answering questions, solving problems, and having meaningful conversations. I know about science, geography, history, culture, math, and many other topics!"
        };
    }

    findAnswer(question) {
        const normalized = question.toLowerCase().trim();
        
        // Direct match
        for (const [key, value] of Object.entries(this.knowledge)) {
            if (normalized.includes(key)) {
                return value;
            }
        }

        // Fuzzy match for similar questions
        for (const [key, value] of Object.entries(this.knowledge)) {
            const keyWords = key.split(' ').filter(w => w.length > 3);
            const matchCount = keyWords.filter(word => normalized.includes(word)).length;
            
            if (matchCount >= 2) {
                return value;
            }
        }

        return null;
    }

    respond(message) {
        const answer = this.findAnswer(message);
        
        if (answer) {
            return answer;
        }

        return "I'm Shree Love AI! Feel free to ask me about myself, or ask me questions about science, geography, history, math, and much more!";
    }
}

module.exports = new PersonalEngine();
