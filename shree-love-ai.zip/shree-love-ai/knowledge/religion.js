class ReligionEngine {
    constructor() {
        this.knowledge = {
            // Christianity
            'who is jesus': 'Jesus Christ is the central figure of Christianity, believed by Christians to be the Son of God and the Savior of humanity.',
            'what is the bible': 'The Bible is the holy scripture of Christianity, consisting of the Old Testament and the New Testament.',
            'who wrote the bible': 'The Bible was written by multiple authors over many centuries, inspired by God according to Christian belief.',
            'what is christmas': 'Christmas is a Christian holiday celebrating the birth of Jesus Christ, observed on December 25th.',
            'what is easter': 'Easter is a Christian festival celebrating the resurrection of Jesus Christ from the dead, considered the most important Christian holiday.',
            'what is prayer': 'Prayer is a way of communicating with God, expressing worship, thanksgiving, confession, or making requests.',
            'ten commandments': 'The Ten Commandments are fundamental moral laws given by God to Moses, found in the Bible, guiding Christian and Jewish ethics.',
            'what is a church': 'A church is a building used for Christian worship and religious activities, and also refers to the community of Christian believers.',
            
            // Hinduism
            'who is krishna': 'Lord Krishna is one of the most important deities in Hinduism, considered the eighth avatar of Lord Vishnu and a central figure in the Bhagavad Gita.',
            'who is rama': 'Lord Rama is a major deity in Hinduism, the seventh avatar of Vishnu, and the hero of the epic Ramayana.',
            'who is shiva': 'Lord Shiva is one of the principal deities in Hinduism, known as the destroyer and transformer in the Hindu trinity (Trimurti).',
            'what is diwali': 'Diwali, the Festival of Lights, is one of the most important Hindu festivals, celebrating the victory of light over darkness and good over evil.',
            'what is holi': 'Holi is a Hindu festival of colors celebrating spring, love, and the victory of good over evil, known for people throwing colored powder.',
            'what is karma': 'Karma is a Hindu and Buddhist concept referring to the principle that actions have consequences, both good and bad, affecting one\'s future.',
            'what is dharma': 'Dharma is a key concept in Hinduism referring to righteous living, moral duty, and the natural order of the universe.',
            'what is the bhagavad gita': 'The Bhagavad Gita is a sacred Hindu scripture that is part of the epic Mahabharata, containing teachings of Lord Krishna to Arjuna.',
            'what is brahma': 'Brahma is the creator god in the Hindu trinity (Trimurti), responsible for creating the universe.',
            'what is vishnu': 'Vishnu is the preserver god in the Hindu trinity, responsible for maintaining and protecting the universe.',
            'what is a temple': 'A temple is a sacred building in Hinduism dedicated to worship of deities, where religious ceremonies and prayers take place.',
            'what is om': 'Om (Aum) is the most sacred sound and symbol in Hinduism, representing the universe and the ultimate reality (Brahman).'
        };
    }

    findAnswer(question) {
        const normalized = question.toLowerCase().trim();
        
        for (const [key, value] of Object.entries(this.knowledge)) {
            if (normalized.includes(key) || this.fuzzyMatch(normalized, key)) {
                return value;
            }
        }

        return null;
    }

    fuzzyMatch(question, key) {
        const keyWords = key.split(' ').filter(w => w.length > 2);
        const matchCount = keyWords.filter(word => question.includes(word)).length;
        return matchCount >= 2;
    }

    respond(message) {
        const answer = this.findAnswer(message);
        
        if (answer) {
            return answer;
        }

        return "I can help with basic questions about Christianity and Hinduism, including beliefs, festivals, and important figures!";
    }
}

module.exports = new ReligionEngine();
