class FullFormsEngine {
    constructor() {
        this.fullForms = {
            'nasa': 'National Aeronautics and Space Administration',
            'who': 'World Health Organization',
            'isro': 'Indian Space Research Organisation',
            'un': 'United Nations',
            'fbi': 'Federal Bureau of Investigation',
            'cia': 'Central Intelligence Agency',
            'ceo': 'Chief Executive Officer',
            'cfo': 'Chief Financial Officer',
            'cto': 'Chief Technology Officer',
            'atm': 'Automated Teller Machine',
            'gps': 'Global Positioning System',
            'html': 'HyperText Markup Language',
            'http': 'HyperText Transfer Protocol',
            'url': 'Uniform Resource Locator',
            'wifi': 'Wireless Fidelity',
            'usb': 'Universal Serial Bus',
            'pdf': 'Portable Document Format',
            'jpeg': 'Joint Photographic Experts Group',
            'png': 'Portable Network Graphics',
            'covid': 'Coronavirus Disease',
            'aids': 'Acquired Immunodeficiency Syndrome',
            'hiv': 'Human Immunodeficiency Virus',
            'dna': 'Deoxyribonucleic Acid',
            'rna': 'Ribonucleic Acid',
            'iq': 'Intelligence Quotient',
            'eq': 'Emotional Quotient',
            'asap': 'As Soon As Possible',
            'fyi': 'For Your Information',
            'rsvp': 'Répondez S\'il Vous Plaît (Please Respond)',
            'etc': 'Et Cetera',
            'vip': 'Very Important Person',
            'aka': 'Also Known As',
            'diy': 'Do It Yourself',
            'faq': 'Frequently Asked Questions',
            'gdp': 'Gross Domestic Product',
            'vat': 'Value Added Tax',
            'gst': 'Goods and Services Tax',
            'atm': 'Automated Teller Machine',
            'pin': 'Personal Identification Number',
            'sms': 'Short Message Service',
            'mms': 'Multimedia Messaging Service',
            'sim': 'Subscriber Identity Module',
            'ram': 'Random Access Memory',
            'rom': 'Read Only Memory',
            'cpu': 'Central Processing Unit',
            'gpu': 'Graphics Processing Unit',
            'ssd': 'Solid State Drive',
            'hdd': 'Hard Disk Drive',
            'led': 'Light Emitting Diode',
            'lcd': 'Liquid Crystal Display',
            'tv': 'Television',
            'dvd': 'Digital Versatile Disc',
            'cd': 'Compact Disc',
            'ac': 'Air Conditioner',
            'dc': 'Direct Current',
            'am': 'Amplitude Modulation',
            'fm': 'Frequency Modulation'
        };
    }

    findFullForm(abbreviation) {
        const normalized = abbreviation.toLowerCase().trim();
        
        // Extract abbreviation from question
        for (const [key, value] of Object.entries(this.fullForms)) {
            if (normalized.includes(key)) {
                return `${key.toUpperCase()} stands for ${value}.`;
            }
        }

        return null;
    }

    respond(message) {
        const answer = this.findFullForm(message);
        
        if (answer) {
            return answer;
        }

        return "I can help with full forms of common abbreviations like NASA, WHO, ISRO, FBI, and many more!";
    }
}

module.exports = new FullFormsEngine();
