class GaroCultureEngine {
    constructor() {
        this.knowledge = {
            'who are the garo people': 'The Garo people are one of the major tribes of Meghalaya, India. They also live in parts of Assam, Bangladesh, and other northeastern states.',
            'garo hills': 'The Garo Hills is a hilly region in Meghalaya, India, inhabited primarily by the Garo people. The administrative center is Tura.',
            'wangala festival': 'Wangala, also known as the 100 Drums Festival, is the most important harvest festival of the Garo people, celebrated in November to honor the Sun God.',
            'garo language': 'The Garo language belongs to the Tibeto-Burman language family and is spoken by the Garo people.',
            'traditional garo dress': 'Traditional Garo dress for women includes the Dakmanda (a sarong-like lower garment) and Daksari (a blouse). Men traditionally wear a loincloth called Gando.',
            'garo matrilineal society': 'Garo society is matrilineal, meaning property and lineage are passed through the mother\'s side. The youngest daughter typically inherits the family property.',
            'garo traditional house': 'Traditional Garo houses are built on bamboo stilts with thatched roofs, designed to protect against the heavy rainfall in the region.',
            'tura': 'Tura is the largest town in the Garo Hills and serves as the administrative headquarters of the West Garo Hills district.',
            'nokpante': 'Nokpante is a traditional Garo dwelling, a communal house where unmarried youth traditionally stayed.',
            'garo food': 'Traditional Garo cuisine includes rice, fish, pork, and chicken, often prepared with minimal spices. Nakham (fermented fish) is a popular ingredient.',
            'garo festivals': 'Important Garo festivals include Wangala (harvest festival), Rongchhugala (winter festival), and Ahaia (sowing festival).',
            'garo traditional dance': 'The Wangala dance, performed during the harvest festival with drums and traditional instruments, is the most famous Garo dance.'
        };
    }

    findAnswer(question) {
        const normalized = question.toLowerCase().trim();
        
        for (const [key, value] of Object.entries(this.knowledge)) {
            if (normalized.includes(key) || this.fuzzyMatch(normalized, key)) {
                return value;
            }
        }

        return null;
    }

    fuzzyMatch(question, key) {
        const keyWords = key.split(' ').filter(w => w.length > 3);
        const matchCount = keyWords.filter(word => question.includes(word)).length;
        return matchCount >= 2;
    }

    respond(message) {
        const answer = this.findAnswer(message);
        
        if (answer) {
            return answer;
        }

        return "I can help with questions about Garo culture, traditions, festivals, lifestyle, and the Garo Hills region!";
    }
}

module.exports = new GaroCultureEngine();
