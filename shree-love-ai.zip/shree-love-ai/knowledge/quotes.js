class QuotesEngine {
    constructor() {
        this.quotes = [
            "\"The only way to do great work is to love what you do.\" - Steve Jobs",
            "\"In the middle of difficulty lies opportunity.\" - Albert Einstein",
            "\"Life is what happens when you're busy making other plans.\" - John Lennon",
            "\"The future belongs to those who believe in the beauty of their dreams.\" - Eleanor Roosevelt",
            "\"It is during our darkest moments that we must focus to see the light.\" - Aristotle",
            "\"Whoever is happy will make others happy too.\" - Anne Frank",
            "\"Do not dwell in the past, do not dream of the future, concentrate the mind on the present moment.\" - Buddha",
            "\"Life is really simple, but we insist on making it complicated.\" - Confucius",
            "\"May you live every day of your life.\" - Jonathan Swift",
            "\"The greatest glory in living lies not in never falling, but in rising every time we fall.\" - Nelson Mandela",
            "\"The way to get started is to quit talking and begin doing.\" - Walt Disney",
            "\"Life is either a daring adventure or nothing at all.\" - Helen Keller",
            "\"The only impossible journey is the one you never begin.\" - Tony Robbins",
            "\"In this life we cannot do great things. We can only do small things with great love.\" - Mother Teresa",
            "\"Success is not final, failure is not fatal: it is the courage to continue that counts.\" - Winston Churchill"
        ];
    }

    getRandomQuote() {
        return this.quotes[Math.floor(Math.random() * this.quotes.length)];
    }

    respond(message) {
        return this.getRandomQuote();
    }
}

module.exports = new QuotesEngine();
