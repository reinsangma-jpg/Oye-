class RomanticEngine {
    constructor() {
        this.responses = [
            "Love is the most beautiful feeling in the world! 💕",
            "Every love story is special, but yours is my favorite! ✨",
            "Love is not just a feeling, it's a beautiful journey together.",
            "In the arithmetic of love, one plus one equals everything, and two minus one equals nothing.",
            "True love is when someone accepts your past, supports your present, and encourages your future.",
            "Love is composed of a single soul inhabiting two bodies.",
            "The best thing to hold onto in life is each other.",
            "Love is when the other person's happiness is more important than your own.",
            "I love you not only for what you are, but for what I am when I am with you.",
            "You are my sun, my moon, and all of my stars. ⭐"
        ];

        this.missYouMessages = [
            "Distance means so little when someone means so much.",
            "Missing someone is your heart's way of reminding you that you love them.",
            "I miss you like the sun misses the flowers in winter.",
            "Every moment without you feels like an eternity.",
            "Though miles may lie between us, we're never far apart, for love doesn't count miles, it's measured by the heart."
        ];
    }

    getRandomResponse(array) {
        return array[Math.floor(Math.random() * array.length)];
    }

    respond(message) {
        const normalized = message.toLowerCase().trim();

        if (normalized.includes('miss you') || normalized.includes('miss u')) {
            return this.getRandomResponse(this.missYouMessages);
        }

        return this.getRandomResponse(this.responses);
    }
}

module.exports = new RomanticEngine();
