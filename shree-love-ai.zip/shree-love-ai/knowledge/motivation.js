class MotivationEngine {
    constructor() {
        this.messages = [
            "Believe in yourself! You have the power to achieve amazing things! 💪",
            "Every day is a new beginning. Take a deep breath and start again!",
            "You are stronger than you think. Keep pushing forward!",
            "Success is not final, failure is not fatal. What matters is the courage to continue!",
            "Your limitation—it's only your imagination. Dream big!",
            "Great things never come from comfort zones. Challenge yourself!",
            "Don't watch the clock; do what it does. Keep going!",
            "The harder you work for something, the greater you'll feel when you achieve it!",
            "Dream bigger. Do bigger. Be bigger!",
            "Don't stop when you're tired. Stop when you're done!",
            "Wake up with determination. Go to bed with satisfaction!",
            "Success doesn't just find you. You have to go out and get it!",
            "The key to success is to focus on goals, not obstacles!",
            "Sometimes we're tested not to show our weaknesses, but to discover our strengths!",
            "Your positive action combined with positive thinking results in success!",
            "You don't have to be great to start, but you have to start to be great!",
            "Believe you can and you're halfway there!",
            "The only person you are destined to become is the person you decide to be!",
            "Opportunities don't happen. You create them!",
            "Don't be afraid to give up the good to go for the great!"
        ];
    }

    getRandomMessage() {
        return this.messages[Math.floor(Math.random() * this.messages.length)];
    }

    respond(message) {
        return this.getRandomMessage();
    }
}

module.exports = new MotivationEngine();
