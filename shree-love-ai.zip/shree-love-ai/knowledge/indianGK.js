class IndianGKEngine {
    constructor() {
        this.knowledge = {
            'capital of india': 'The capital of India is New Delhi.',
            'prime minister of india': 'Narendra Modi is the current Prime Minister of India.',
            'president of india': 'The President of India changes periodically. Please check current news for the latest information.',
            'largest state in india': 'Rajasthan is the largest state in India by area.',
            'smallest state in india': 'Goa is the smallest state in India by area.',
            'most populated state in india': 'Uttar Pradesh is the most populated state in India.',
            'when did india gain independence': 'India gained independence on August 15, 1947.',
            'who is the father of the nation': 'Mahatma Gandhi is known as the Father of the Nation in India.',
            'first prime minister of india': 'Jawaharlal Nehru was the first Prime Minister of India.',
            'national animal of india': 'The Bengal Tiger is the national animal of India.',
            'national bird of india': 'The Indian Peacock is the national bird of India.',
            'national flower of india': 'The Lotus is the national flower of India.',
            'national anthem of india': 'Jana Gana Mana, written by Rabindranath Tagore, is the national anthem of India.',
            'how many states in india': 'India has 28 states and 8 Union Territories.',
            'longest river in india': 'The Ganges (Ganga) is the longest river in India, stretching about 2,525 km.',
            'highest mountain in india': 'Kangchenjunga is the highest mountain peak entirely in India at 8,586 meters.',
            'largest city in india': 'Mumbai is the largest city in India by population.',
            'who wrote the indian constitution': 'Dr. B.R. Ambedkar is known as the chief architect of the Indian Constitution.',
            'when was the constitution of india adopted': 'The Constitution of India was adopted on November 26, 1949, and came into effect on January 26, 1950.',
            'independence day of india': 'India celebrates Independence Day on August 15th every year.',
            'republic day of india': 'India celebrates Republic Day on January 26th every year.'
        };
    }

    findAnswer(question) {
        const normalized = question.toLowerCase().trim();
        
        for (const [key, value] of Object.entries(this.knowledge)) {
            if (normalized.includes(key) || this.fuzzyMatch(normalized, key)) {
                return value;
            }
        }

        return null;
    }

    fuzzyMatch(question, key) {
        const keyWords = key.split(' ').filter(w => w.length > 3);
        const matchCount = keyWords.filter(word => question.includes(word)).length;
        return matchCount >= 2;
    }

    respond(message) {
        const answer = this.findAnswer(message);
        
        if (answer) {
            return answer;
        }

        return "I can help with questions about Indian history, geography, politics, culture, and national symbols!";
    }
}

module.exports = new IndianGKEngine();
