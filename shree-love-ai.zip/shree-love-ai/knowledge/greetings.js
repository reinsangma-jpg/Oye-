class GreetingsEngine {
    constructor() {
        this.greetings = [
            "Hello! I'm Shree Love AI. How can I help you today?",
            "Hi there! Nice to see you! What would you like to know?",
            "Hey! I'm here to help with your questions!",
            "Greetings! What can I assist you with today?",
            "Hello! Ready to chat and help you learn!",
            "Hi! I'm Shree Love AI, your friendly assistant!"
        ];

        this.timeBasedGreetings = {
            morning: [
                "Good morning! Hope you're having a wonderful day! How can I help?",
                "Good morning! Ready to start the day with some learning?"
            ],
            afternoon: [
                "Good afternoon! How can I brighten your day?",
                "Good afternoon! What can I help you with?"
            ],
            evening: [
                "Good evening! How has your day been? What can I help with?",
                "Good evening! Ready to chat and learn?"
            ],
            night: [
                "Good night! Still here to help before you rest!",
                "Hello! Even at night, I'm here for you!"
            ]
        };
    }

    getRandomGreeting(greetingArray) {
        return greetingArray[Math.floor(Math.random() * greetingArray.length)];
    }

    respond(message) {
        const normalized = message.toLowerCase().trim();

        // Time-based greetings
        if (normalized.includes('good morning')) {
            return this.getRandomGreeting(this.timeBasedGreetings.morning);
        }
        if (normalized.includes('good afternoon')) {
            return this.getRandomGreeting(this.timeBasedGreetings.afternoon);
        }
        if (normalized.includes('good evening')) {
            return this.getRandomGreeting(this.timeBasedGreetings.evening);
        }
        if (normalized.includes('good night')) {
            return this.getRandomGreeting(this.timeBasedGreetings.night);
        }

        // General greetings
        return this.getRandomGreeting(this.greetings);
    }
}

module.exports = new GreetingsEngine();
