class AssamHistoryEngine {
    constructor() {
        this.knowledge = {
            'ahom kingdom': 'The Ahom Kingdom ruled Assam for nearly 600 years (1228-1826). They were a Tai ethnic group from present-day Myanmar who established a powerful kingdom in Assam.',
            'who founded ahom kingdom': 'Sukaphaa (also spelled Chaolung Sukapha) founded the Ahom Kingdom in 1228.',
            'lachit borphukan': 'Lachit Borphukan was a legendary Ahom general who led the Assamese forces to victory against the Mughal Empire in the Battle of Saraighat in 1671.',
            'battle of saraighat': 'The Battle of Saraighat (1671) was a naval battle fought on the Brahmaputra River where Lachit Borphukan defeated the Mughal forces, protecting Assam from Mughal invasion.',
            'ahom monuments': 'Important Ahom monuments include the Rang Ghar (amphitheater), Talatal Ghar (palace), and Kareng Ghar in Sivasagar.',
            'when did british rule assam': 'The British took control of Assam after the Treaty of Yandabo in 1826, following the First Anglo-Burmese War.',
            'treaty of yandabo': 'The Treaty of Yandabo (1826) ended the First Anglo-Burmese War and resulted in Assam coming under British control.',
            'rangpur': 'Rangpur was an important historical city during the Ahom period, known for military activities.',
            'sivasagar history': 'Sivasagar (formerly Rangpur) served as the capital of the Ahom Kingdom and contains many historical monuments.',
            'ahom script': 'The Ahom script was used to write the Ahom language and many historical records. It is derived from the Tai script.'
        };
    }

    findAnswer(question) {
        const normalized = question.toLowerCase().trim();
        
        for (const [key, value] of Object.entries(this.knowledge)) {
            if (normalized.includes(key) || this.fuzzyMatch(normalized, key)) {
                return value;
            }
        }

        return null;
    }

    fuzzyMatch(question, key) {
        const keyWords = key.split(' ').filter(w => w.length > 3);
        const matchCount = keyWords.filter(word => question.includes(word)).length;
        return matchCount >= 2;
    }

    respond(message) {
        const answer = this.findAnswer(message);
        
        if (answer) {
            return answer;
        }

        return "I can help with Assam's history, including the Ahom Kingdom, Lachit Borphukan, and important historical events!";
    }
}

module.exports = new AssamHistoryEngine();
