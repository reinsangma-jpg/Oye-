class GKEngine {
    constructor() {
        this.knowledge = {
            'who is the president of usa': 'As of my last update, Joe Biden is the President of the United States.',
            'who invented the telephone': 'Alexander Graham Bell is credited with inventing the telephone in 1876.',
            'who invented the light bulb': 'Thomas Edison invented the practical incandescent light bulb in 1879.',
            'who invented the computer': 'Charles Babbage is often called the "father of the computer" for his work on the Analytical Engine in the 1830s.',
            'who discovered america': 'Christopher Columbus is credited with discovering America in 1492, though indigenous peoples lived there long before.',
            'who invented the airplane': 'The Wright Brothers, Orville and Wilbur Wright, invented and flew the first successful airplane in 1903.',
            'when was world war 1': 'World War I took place from 1914 to 1918.',
            'when was world war 2': 'World War II took place from 1939 to 1945.',
            'who won world war 2': 'The Allied Powers (including the USA, UK, Soviet Union, and France) won World War II against the Axis Powers.',
            'largest country by population': 'India is projected to be the most populous country, having recently surpassed China.',
            'who painted the mona lisa': 'Leonardo da Vinci painted the Mona Lisa in the early 16th century.',
            'how many countries in the world': 'There are 195 countries in the world today: 193 UN member states and 2 observer states (Vatican City and Palestine).',
            'who is the richest person': 'The richest person changes frequently, but recent contenders include Elon Musk, Bernard Arnault, and Jeff Bezos.',
            'what is the united nations': 'The United Nations (UN) is an international organization founded in 1945 to promote peace, security, and cooperation among nations.',
            'who wrote romeo and juliet': 'William Shakespeare wrote Romeo and Juliet around 1594-1596.',
            'when was the internet invented': 'The internet was developed in the late 1960s and early 1970s, with ARPANET being launched in 1969.'
        };
    }

    findAnswer(question) {
        const normalized = question.toLowerCase().trim();
        
        for (const [key, value] of Object.entries(this.knowledge)) {
            const keyWords = key.split(' ').filter(w => w.length > 3);
            const matchCount = keyWords.filter(word => normalized.includes(word)).length;
            
            if (matchCount >= 2 || normalized.includes(key)) {
                return value;
            }
        }

        return null;
    }

    respond(message) {
        const answer = this.findAnswer(message);
        
        if (answer) {
            return answer;
        }

        return "I can help with general knowledge questions about world history, famous people, inventions, and global facts!";
    }
}

module.exports = new GKEngine();
