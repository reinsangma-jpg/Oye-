class GeographyEngine {
    constructor() {
        this.knowledge = {
            'capital of india': 'New Delhi',
            'capital of usa': 'Washington, D.C.',
            'capital of uk': 'London',
            'capital of france': 'Paris',
            'capital of germany': 'Berlin',
            'capital of japan': 'Tokyo',
            'capital of china': 'Beijing',
            'capital of russia': 'Moscow',
            'capital of australia': 'Canberra',
            'capital of canada': 'Ottawa',
            'capital of brazil': 'Brasília',
            'capital of italy': 'Rome',
            'capital of spain': 'Madrid',
            'capital of mexico': 'Mexico City',
            'capital of south africa': 'Pretoria (executive), Cape Town (legislative), Bloemfontein (judicial)',
            'capital of egypt': 'Cairo',
            'capital of thailand': 'Bangkok',
            'capital of singapore': 'Singapore',
            'capital of pakistan': 'Islamabad',
            'capital of bangladesh': 'Dhaka',
            'capital of nepal': 'Kathmandu',
            'capital of sri lanka': 'Colombo (commercial), Sri Jayawardenepura Kotte (legislative)',
            'tallest mountain': 'Mount Everest is the tallest mountain in the world, standing at 8,848.86 meters (29,031.7 feet) above sea level.',
            'longest river': 'The Nile River is considered the longest river in the world, stretching approximately 6,650 kilometers (4,130 miles).',
            'largest ocean': 'The Pacific Ocean is the largest ocean, covering about 165 million square kilometers.',
            'largest desert': 'The Antarctic Desert is the largest desert in the world. The Sahara is the largest hot desert.',
            'largest country': 'Russia is the largest country by land area, covering about 17.1 million square kilometers.',
            'smallest country': 'Vatican City is the smallest country in the world, with an area of about 0.44 square kilometers.',
            'largest continent': 'Asia is the largest continent, covering about 44.58 million square kilometers.',
            'smallest continent': 'Australia is the smallest continent, covering about 7.69 million square kilometers.',
            'how many continents': 'There are seven continents: Asia, Africa, North America, South America, Antarctica, Europe, and Australia.',
            'how many oceans': 'There are five oceans: Pacific, Atlantic, Indian, Southern, and Arctic.',
            'brahmaputra river': 'The Brahmaputra is a major river in Asia, flowing through Tibet, India, and Bangladesh. It is about 2,900 km long.',
            'ganges river': 'The Ganges (or Ganga) is a sacred river in India, flowing about 2,525 km from the Himalayas to the Bay of Bengal.',
            'amazon river': 'The Amazon River is the second longest river in the world, flowing through South America, primarily Brazil.',
            'mount everest': 'Mount Everest is the highest mountain peak in the world, located in the Himalayas on the border between Nepal and Tibet.',
            'sahara desert': 'The Sahara is the largest hot desert in the world, covering much of North Africa.'
        };
    }

    findAnswer(question) {
        const normalized = question.toLowerCase().trim();
        
        // Direct match
        for (const [key, value] of Object.entries(this.knowledge)) {
            if (normalized.includes(key)) {
                return value;
            }
        }

        // Check for "capital of" pattern
        if (normalized.includes('capital')) {
            return "I can help you with capitals of various countries! Try asking about the capital of India, USA, France, Japan, or any other country.";
        }

        return null;
    }

    respond(message) {
        const answer = this.findAnswer(message);
        
        if (answer) {
            return answer;
        }

        return "I can help with geography questions about countries, capitals, rivers, mountains, and continents!";
    }
}

module.exports = new GeographyEngine();
