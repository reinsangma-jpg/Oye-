class EconomicsEngine {
    constructor() {
        this.knowledge = {
            'what is gdp': 'GDP (Gross Domestic Product) is the total monetary value of all finished goods and services produced within a country during a specific time period. It is a key indicator of economic health.',
            'what is inflation': 'Inflation is the rate at which the general level of prices for goods and services rises, causing purchasing power to fall. It is typically measured as an annual percentage increase.',
            'what is demand': 'Demand is the quantity of a good or service that consumers are willing and able to purchase at various prices during a given period.',
            'what is supply': 'Supply is the quantity of a good or service that producers are willing and able to offer for sale at various prices during a given period.',
            'what is tax': 'Tax is a compulsory financial charge imposed by the government on individuals or businesses to fund public expenditures.',
            'what is fiscal policy': 'Fiscal policy refers to government spending and taxation decisions used to influence the economy, particularly to manage economic growth and employment.',
            'what is monetary policy': 'Monetary policy is the process by which a central bank manages the money supply and interest rates to achieve economic goals like controlling inflation and stabilizing currency.',
            'what is recession': 'A recession is a significant decline in economic activity across the economy lasting more than a few months, typically visible in GDP, employment, and trade.',
            'what is unemployment': 'Unemployment refers to the situation where people who are willing and able to work cannot find jobs. The unemployment rate is the percentage of the labor force that is jobless.',
            'what is market': 'A market is a system or place where buyers and sellers interact to exchange goods, services, or information, and where prices are determined by supply and demand.',
            'what is export': 'Export is the act of selling goods or services produced in one country to buyers in another country.',
            'what is import': 'Import is the act of buying goods or services from another country and bringing them into one\'s own country.',
            'what is trade deficit': 'A trade deficit occurs when a country imports more goods and services than it exports, resulting in negative net exports.',
            'what is interest rate': 'An interest rate is the percentage charged on borrowed money or earned on invested money, typically expressed as an annual percentage.',
            'what is capital': 'Capital refers to financial assets or resources used to produce goods and services, including money, machinery, buildings, and other productive assets.',
            'what is profit': 'Profit is the financial gain obtained when the revenue from business activities exceeds the expenses, costs, and taxes.',
            'what is revenue': 'Revenue is the total income generated from the sale of goods or services before any costs or expenses are deducted.',
            'what is stock market': 'The stock market is a marketplace where shares of publicly traded companies are bought and sold, allowing companies to raise capital and investors to potentially earn returns.',
            'what is exchange rate': 'An exchange rate is the value of one currency in terms of another currency, determining how much of one currency you can get for another.'
        };
    }

    findAnswer(question) {
        const normalized = question.toLowerCase().trim();
        
        // Direct match
        for (const [key, value] of Object.entries(this.knowledge)) {
            if (normalized.includes(key.replace('what is ', ''))) {
                return value;
            }
        }

        return null;
    }

    respond(message) {
        const answer = this.findAnswer(message);
        
        if (answer) {
            return answer;
        }

        return "I can help explain economic concepts like GDP, inflation, demand, supply, taxation, and market dynamics!";
    }
}

module.exports = new EconomicsEngine();
