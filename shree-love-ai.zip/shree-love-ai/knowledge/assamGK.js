class AssamGKEngine {
    constructor() {
        this.knowledge = {
            'capital of assam': 'Dispur is the capital of Assam.',
            'largest city in assam': 'Guwahati is the largest city in Assam.',
            'chief minister of assam': 'The Chief Minister of Assam changes with elections. Please check current news for the latest.',
            'main river of assam': 'The Brahmaputra is the main river of Assam.',
            'when was assam formed': 'Assam as a state was reorganized on January 26, 1950.',
            'national park in assam': 'Kaziranga National Park is the most famous national park in Assam, known for one-horned rhinoceros.',
            'bihu festival': 'Bihu is the most important festival of Assam, celebrated three times a year: Bohag Bihu (spring), Kati Bihu (autumn), and Magh Bihu (winter).',
            'official language of assam': 'Assamese is the official language of Assam.',
            'state animal of assam': 'The one-horned rhinoceros is the state animal of Assam.',
            'state bird of assam': 'The white-winged duck is the state bird of Assam.',
            'state flower of assam': 'The Foxtail Orchid (Kopou Phool) is the state flower of Assam.',
            'famous tea in assam': 'Assam is world-famous for its tea. Assam tea is known for its strong, malty flavor.',
            'majuli island': 'Majuli is the world\'s largest river island, located in the Brahmaputra River in Assam.',
            'kamakhya temple': 'Kamakhya Temple is a famous Hindu temple in Guwahati, Assam, dedicated to Goddess Kamakhya.',
            'manas national park': 'Manas National Park is a UNESCO World Heritage Site in Assam, known for its biodiversity.',
            'total districts in assam': 'Assam has 33 districts (as of recent administrative divisions).',
            'sivasagar': 'Sivasagar was the capital of the Ahom Kingdom and is an important historical city in Assam.',
            'traditional dress of assam': 'Mekhela Chador is the traditional dress worn by Assamese women.',
            'assamese new year': 'Rongali Bihu (also called Bohag Bihu) marks the Assamese New Year, celebrated in mid-April.'
        };
    }

    findAnswer(question) {
        const normalized = question.toLowerCase().trim();
        
        for (const [key, value] of Object.entries(this.knowledge)) {
            if (normalized.includes(key) || this.fuzzyMatch(normalized, key)) {
                return value;
            }
        }

        return null;
    }

    fuzzyMatch(question, key) {
        const keyWords = key.split(' ').filter(w => w.length > 3);
        const matchCount = keyWords.filter(word => question.includes(word)).length;
        return matchCount >= 2;
    }

    respond(message) {
        const answer = this.findAnswer(message);
        
        if (answer) {
            return answer;
        }

        return "I can help with questions about Assam's geography, culture, festivals, wildlife, and important facts!";
    }
}

module.exports = new AssamGKEngine();
