class ScienceEngine {
    constructor() {
        this.knowledge = {
            'what is an atom': 'An atom is the smallest unit of matter that retains the properties of an element. It consists of a nucleus containing protons and neutrons, surrounded by electrons.',
            'what is gravity': 'Gravity is a fundamental force of nature that attracts objects with mass toward each other. On Earth, it gives weight to physical objects and causes them to fall toward the ground.',
            'what is photosynthesis': 'Photosynthesis is the process by which plants use sunlight, water, and carbon dioxide to produce oxygen and energy in the form of sugar (glucose).',
            'what is energy': 'Energy is the capacity to do work. It exists in various forms such as kinetic, potential, thermal, electrical, chemical, and nuclear energy.',
            'what is a cell': 'A cell is the basic structural and functional unit of all living organisms. It is the smallest unit of life that can replicate independently.',
            'what is dna': 'DNA (Deoxyribonucleic Acid) is a molecule that carries the genetic instructions for the development, functioning, growth, and reproduction of all living organisms.',
            'what is the speed of light': 'The speed of light in a vacuum is approximately 299,792,458 meters per second (about 186,282 miles per second).',
            'what is evolution': 'Evolution is the process by which different kinds of living organisms develop and diversify from earlier forms during the history of the Earth.',
            'what is a molecule': 'A molecule is a group of two or more atoms held together by chemical bonds. It is the smallest unit of a chemical compound.',
            'what is force': 'Force is a push or pull acting upon an object resulting from its interaction with another object. It can cause an object to accelerate, decelerate, or change direction.',
            'what is mass': 'Mass is a measure of the amount of matter in an object. It is constant regardless of location and differs from weight, which depends on gravity.',
            'what is an electron': 'An electron is a negatively charged subatomic particle that orbits the nucleus of an atom. Electrons are responsible for chemical bonding and electrical conductivity.',
            'what is a proton': 'A proton is a positively charged subatomic particle found in the nucleus of an atom. The number of protons determines the element.',
            'what is a neutron': 'A neutron is a subatomic particle with no electric charge, found in the nucleus of atoms. It has approximately the same mass as a proton.',
            'what is electricity': 'Electricity is the flow of electrical charge, typically carried by electrons through a conductor like a wire.',
            'what is magnetism': 'Magnetism is a force that attracts or repels certain materials, particularly iron and steel. It is produced by moving electric charges.',
            'what is temperature': 'Temperature is a measure of the average kinetic energy of particles in a substance. It indicates how hot or cold something is.',
            'what is pressure': 'Pressure is the force applied perpendicular to the surface of an object per unit area. It is measured in units like pascals or pounds per square inch.',
            'what is sound': 'Sound is a vibration that propagates through a medium (like air, water, or solids) as a wave. It is detected by our ears and interpreted as what we hear.',
            'what is light': 'Light is electromagnetic radiation that is visible to the human eye. It behaves both as a wave and as particles called photons.',
            'what is water cycle': 'The water cycle is the continuous movement of water on, above, and below the surface of Earth through processes like evaporation, condensation, precipitation, and runoff.',
            'what is osmosis': 'Osmosis is the movement of water molecules through a semi-permeable membrane from a region of lower solute concentration to a region of higher solute concentration.',
            'what is mitosis': 'Mitosis is a type of cell division that results in two daughter cells, each having the same number and kind of chromosomes as the parent nucleus.',
            'what is an ecosystem': 'An ecosystem is a community of living organisms interacting with each other and their physical environment.',
            'what is acid': 'An acid is a chemical substance that donates hydrogen ions (H+) in a solution and has a pH value less than 7.',
            'what is a base': 'A base is a chemical substance that accepts hydrogen ions or donates hydroxide ions (OH-) in a solution and has a pH value greater than 7.',
            'what is newton\'s first law': 'Newton\'s First Law states that an object at rest stays at rest and an object in motion stays in motion with the same speed and direction unless acted upon by an unbalanced force.',
            'what is newton\'s second law': 'Newton\'s Second Law states that the acceleration of an object depends on the mass of the object and the force applied. F = ma (Force equals mass times acceleration).',
            'what is newton\'s third law': 'Newton\'s Third Law states that for every action, there is an equal and opposite reaction.',
            'what is kinetic energy': 'Kinetic energy is the energy an object possesses due to its motion. It depends on the object\'s mass and velocity.',
            'what is potential energy': 'Potential energy is stored energy that an object has due to its position or state. For example, a raised object has gravitational potential energy.',
            'what is the periodic table': 'The periodic table is a tabular arrangement of chemical elements organized by their atomic number, electron configuration, and recurring chemical properties.',
            'what is carbon': 'Carbon is a chemical element with symbol C and atomic number 6. It is the basis of all organic compounds and essential for life.',
            'what is oxygen': 'Oxygen is a chemical element with symbol O and atomic number 8. It is essential for respiration in most living organisms.',
            'what is hydrogen': 'Hydrogen is a chemical element with symbol H and atomic number 1. It is the lightest and most abundant element in the universe.',
            'what is evaporation': 'Evaporation is the process by which a liquid turns into a gas or vapor, typically due to an increase in temperature.',
            'what is condensation': 'Condensation is the process by which water vapor in the air is changed into liquid water, often forming clouds or dew.',
            'what is friction': 'Friction is a force that opposes the relative motion between two surfaces in contact. It can slow down or prevent movement.',
            'what is velocity': 'Velocity is the rate of change of an object\'s position with respect to time, including both speed and direction.',
            'what is acceleration': 'Acceleration is the rate of change of velocity over time. It can be positive (speeding up) or negative (slowing down).',
            'what is density': 'Density is the mass of a substance per unit volume. It determines whether an object will float or sink in a fluid.',
            'what is respiration': 'Respiration is the biochemical process by which cells convert glucose and oxygen into energy (ATP), carbon dioxide, and water.',
            'what is the nervous system': 'The nervous system is the network of nerve cells and fibers that transmits signals between different parts of the body, coordinating actions and sensory information.',
            'what is the circulatory system': 'The circulatory system is the organ system that circulates blood throughout the body, delivering oxygen and nutrients while removing waste products.',
            'what is an enzyme': 'An enzyme is a biological catalyst that speeds up chemical reactions in living organisms without being consumed in the process.',
            'what is a chromosome': 'A chromosome is a thread-like structure of DNA and proteins that carries genetic information. Humans have 46 chromosomes in most cells.',
            'what is biodiversity': 'Biodiversity is the variety of life on Earth, including the variety of species, their genetic variation, and the ecosystems they form.',
            'what is global warming': 'Global warming is the long-term increase in Earth\'s average surface temperature due to human activities, primarily the emission of greenhouse gases.',
            'what is the greenhouse effect': 'The greenhouse effect is the warming of Earth\'s surface caused by greenhouse gases in the atmosphere trapping heat from the sun.',
            'what is climate change': 'Climate change refers to long-term shifts in global or regional climate patterns, particularly the rise in global temperatures attributed to increased levels of atmospheric carbon dioxide.'
        };
    }

    findAnswer(question) {
        const normalized = question.toLowerCase().trim();
        
        // Direct match
        if (this.knowledge[normalized]) {
            return this.knowledge[normalized];
        }

        // Fuzzy match - check if question contains key phrases
        for (const [key, value] of Object.entries(this.knowledge)) {
            const keyWords = key.split(' ').filter(w => w.length > 3);
            const matchCount = keyWords.filter(word => normalized.includes(word)).length;
            
            if (matchCount >= 2) {
                return value;
            }
        }

        return null;
    }

    respond(message) {
        const answer = this.findAnswer(message);
        
        if (answer) {
            return answer;
        }

        return "That's an interesting science question! While I don't have specific information about that, I can help with topics like atoms, gravity, photosynthesis, energy, and many more.";
    }
}

module.exports = new ScienceEngine();
