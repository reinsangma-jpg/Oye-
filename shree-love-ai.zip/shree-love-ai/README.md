# Shree Love AI 🤖✨

A beautiful, modern AI chat website with an intelligent intent detection system, modular architecture, and stunning 3D animated UI design.

## 🌟 Features

- **Smart Intent Detection System** - Understands the meaning of questions, not just exact matches
- **Modular Architecture** - Clean, organized code structure with separate knowledge engines
- **50+ Science Q&A** - Comprehensive science knowledge base
- **Multiple Knowledge Domains**:
  - Science (Physics, Chemistry, Biology)
  - Geography (Countries, Capitals, Rivers, Mountains)
  - Economics (GDP, Inflation, Markets)
  - General Knowledge
  - Indian GK
  - Assam GK & History
  - Garo Culture
  - Religion (Christianity & Hinduism)
  - Full Forms (NASA, WHO, ISRO, etc.)
- **Math Solving Engine** - Solves addition, subtraction, multiplication, division, percentages
- **Conversational Engines**:
  - Greetings
  - Romantic messages
  - Motivational quotes
  - Inspirational quotes
  - Personal AI questions
- **Modern UI Design**:
  - Liquidmorphism + Glassmorphism + Neomorphism
  - 3D animated background with floating blobs
  - Smooth hover animations
  - Glowing UI elements
  - Pink, purple, blue gradient color palette
- **Typing Effect** - AI responses appear word by word like a real person typing
- **Mobile Responsive** - Works perfectly on all devices

## 📁 Project Structure

```
/shree-love-ai
├── index.html              # Main HTML file
├── style.css               # Main styles with morphism design
├── animations.css          # 3D animations and effects
├── chat.js                 # Chat functionality
├── typingEffect.js         # Typing animation
├── server.js               # Node.js server
├── routes.js               # API routes
├── package.json            # Dependencies
├── /ai
│   └── intentDetector.js   # Intent detection engine
└── /knowledge
    ├── science.js          # Science knowledge (50 Q&A)
    ├── geography.js        # Geography knowledge
    ├── economics.js        # Economics knowledge
    ├── gk.js               # General knowledge
    ├── indianGK.js         # Indian GK
    ├── assamGK.js          # Assam GK
    ├── assamHistory.js     # Assam History
    ├── garoCulture.js      # Garo Culture
    ├── religion.js         # Religion knowledge
    ├── fullForms.js        # Abbreviations & full forms
    ├── mathEngine.js       # Math solver
    ├── greetings.js        # Greeting responses
    ├── romantic.js         # Romantic messages
    ├── quotes.js           # Inspirational quotes
    ├── motivation.js       # Motivational messages
    └── personal.js         # Personal AI questions
```

## 🚀 Installation

### Prerequisites

- Node.js (version 14 or higher)
- npm (comes with Node.js)

### Steps

1. **Extract the project folder**

2. **Navigate to the project directory**
   ```bash
   cd shree-love-ai
   ```

3. **Install dependencies**
   ```bash
   npm install
   ```

4. **Start the server**
   ```bash
   npm start
   ```

5. **Open your browser**
   - Go to `http://localhost:3000`
   - Enjoy chatting with Shree Love AI!

## 🛠️ Development Mode

To run the server with auto-restart on file changes:

```bash
npm run dev
```

## 💬 Example Questions

### Science
- What is an atom?
- What is photosynthesis?
- What is gravity?

### Geography
- What is the capital of India?
- Tell me about Mount Everest
- What is the longest river?

### Economics
- What is GDP?
- Explain inflation
- What is demand and supply?

### Math
- 25 + 40
- 144 / 12
- 20% of 500

### General Knowledge
- Who invented the telephone?
- When was World War 2?
- Who painted the Mona Lisa?

### Indian GK
- What is the national bird of India?
- When did India gain independence?
- Who wrote the Indian constitution?

### Assam
- What is the capital of Assam?
- Tell me about Kaziranga
- What is Bihu festival?

### Personal
- What is your name?
- Who created you?
- What can you do?

### Conversational
- Hello
- Good morning
- I love you
- Motivate me
- Give me a quote

## 🎨 Design Features

- **Glassmorphism**: Transparent, frosted glass effect
- **Neomorphism**: Soft, 3D embossed elements
- **Liquidmorphism**: Smooth, flowing blob animations
- **Gradient Colors**: Pink (#ff6ec7), Purple (#b06aff), Blue (#6eb4ff)
- **3D Blobs**: 5 animated floating blobs in the background
- **Smooth Animations**: All interactions have smooth transitions

## 🔧 How It Works

1. **User sends a message** → Frontend (chat.js)
2. **Message sent to backend** → Server (server.js) → Routes (routes.js)
3. **Intent Detection** → AI (intentDetector.js) analyzes the message
4. **Category Detection** → Determines which knowledge engine to use
5. **Knowledge Engine** → Specific engine processes the question
6. **Response Generated** → Answer sent back to frontend
7. **Typing Effect** → Response appears word by word

## 📱 Mobile Support

The website is fully responsive and works beautifully on:
- Desktop computers
- Tablets
- Smartphones
- All screen sizes

## 🌐 Browser Support

- Chrome (recommended)
- Firefox
- Safari
- Edge
- Opera

## 📝 Customization

### Adding New Knowledge

To add new topics or questions:

1. Open the relevant knowledge file (e.g., `knowledge/science.js`)
2. Add new question-answer pairs to the knowledge object
3. Save the file
4. Restart the server

### Changing Colors

To modify the color scheme:

1. Open `style.css`
2. Edit the `:root` variables at the top
3. Save and refresh the browser

### Adjusting Typing Speed

To change how fast the AI types:

1. Open `chat.js`
2. Find the line: `new window.TypingEffect(messageText, text, 30);`
3. Change `30` to your desired speed (lower = faster)

## 🔒 Performance

- Fast response times
- Smooth animations
- Optimized for mobile
- No lag or delays
- Efficient intent detection

## 🎯 Future Enhancements

Possible additions:
- Voice input/output
- More knowledge domains
- Multi-language support
- User accounts and chat history
- Advanced math calculations
- Image recognition

## 🤝 Contributing

Feel free to fork this project and add your own features!

## 📄 License

This project is open source and available under the MIT License.

## 👏 Credits

Created with ❤️ for knowledge sharing and meaningful conversations.

---

**Enjoy chatting with Shree Love AI!** 🚀✨
