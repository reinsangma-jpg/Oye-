// Typing Effect Class
class TypingEffect {
    constructor(element, text, speed = 30) {
        this.element = element;
        this.text = text;
        this.speed = speed; // milliseconds per character
        this.currentIndex = 0;
        
        this.startTyping();
    }

    startTyping() {
        this.element.textContent = '';
        this.type();
    }

    type() {
        if (this.currentIndex < this.text.length) {
            this.element.textContent += this.text.charAt(this.currentIndex);
            this.currentIndex++;
            
            // Scroll to bottom as text appears
            if (window.chatApp) {
                window.chatApp.scrollToBottom();
            }
            
            setTimeout(() => this.type(), this.speed);
        }
    }

    stop() {
        this.currentIndex = this.text.length;
        this.element.textContent = this.text;
    }
}

// Make TypingEffect available globally
window.TypingEffect = TypingEffect;
